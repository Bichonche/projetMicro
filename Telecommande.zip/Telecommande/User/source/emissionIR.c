#include "lpc17xx_timer.h"
#include "lpc17xx_dac.h"

int freq;

typedef struct message
{
	char dir;
	int_8t b valeur;
}typeMessage;

typeMessage tabMessage[8];



TIM_Init(*TIM0, TIM_TIMER_MODE, 
void emitMessage(typeMessage message)
{
	
}
 //Utilisation de TIMER0

//Initialiser TIMER0 pour la frequence porteuse

void start
{
		
}

